<?php

$db = new Conexion();
include(HTML_DIR . 'Vistas/login.php');
$db->close();
?>
