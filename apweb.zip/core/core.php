<?php 

session_start();

#Constantes de conexión
define('DB_HOST','127.0.0.1');
define('DB_USER','u326008933_apweb');
define('DB_PASS','Cr3d1t0Gl0bal');
define('DB_NAME','u326008933_apweb');
define('HTML_DIR','pages/');
define('PATH_COMPLEMENTO','');

//Cr3d1t0Gl0bal
//u326008933_apweb
require('core/Models/class.Conexion.php');
require('core/Models/Encrypt.php');

?>
